package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Rand;
import com.mendingz.client.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AimAssist extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 4.5, 1, 8, 0.5));
    private final Setting.Num fov = add(new Setting.Num("FOV", 90, 10, 180, 5));
    private final Setting.Num speed = add(new Setting.Num("Speed", 5, 1, 20, 1));
    private final Setting.Mode point = add(new Setting.Mode("Aim Point", 1, "Head", "Chest", "Feet"));
    private final Setting.Bool onlyClick = add(new Setting.Bool("Only When Clicking", true));

    public AimAssist() {
        super("AimAssist", Category.COMBAT, GLFW.GLFW_KEY_G);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        if (onlyClick.value && !mc.options.attackKey.isPressed()) return;

        Vec3d eye = mc.player.getEyePos();
        double bestAngle = fov.value / 2.0;
        float bestYaw = 0, bestPitch = 0;
        boolean found = false;

        for (PlayerEntity p : Targets.players(mc, range.value, false)) {
            double f = point.index == 0 ? 0.93 : point.index == 1 ? 0.65 : 0.1;
            Vec3d aim = new Vec3d(p.getX(), p.getY() + p.getHeight() * f, p.getZ());
            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
            float dyaw = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
            float dpitch = pitch - mc.player.getPitch();
            double ang = Math.hypot(dyaw, dpitch);
            if (ang < bestAngle) {
                bestAngle = ang;
                bestYaw = dyaw;
                bestPitch = dpitch;
                found = true;
            }
        }
        if (!found) return;

        float s = (float) (speed.value / 25.0 * (0.8 + Rand.d() * 0.4));
        mc.player.setYaw(mc.player.getYaw() + bestYaw * s);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + bestPitch * s, -90f, 90f));
    }
}

package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Inv;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public class AutoTotem extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", 6, 1, 20, 1));
    private final Setting.Bool always = add(new Setting.Bool("Always Equip", true));
    private final Setting.Num delayMin = add(new Setting.Num("Delay Min (ms)", 90, 0, 500, 10));
    private final Setting.Num delayMax = add(new Setting.Num("Delay Max (ms)", 220, 0, 500, 10));
    private final Setting.Bool hotbarOnly = add(new Setting.Bool("Hotbar Only", false));
    private long readyAt = -1;

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT, GLFW.GLFW_KEY_T);
    }

    @Override
    protected void onDisable() {
        readyAt = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen instanceof HandledScreen) return;
        boolean has = mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        boolean need = !has && (always.value || mc.player.getHealth() <= health.value);
        if (!need) {
            readyAt = -1;
            return;
        }
        long now = System.currentTimeMillis();
        if (readyAt < 0) {
            readyAt = now + Rand.range(delayMin.value, delayMax.value);
            return;
        }
        if (now < readyAt) return;
        readyAt = -1;

        if (!mc.player.currentScreenHandler.getCursorStack().isEmpty()) return;
        int slot = hotbarOnly.value ? Inv.findHotbar(s -> s.isOf(Items.TOTEM_OF_UNDYING))
            : Inv.findInventory(s -> s.isOf(Items.TOTEM_OF_UNDYING));
        if (slot != -1) Inv.swapOffhand(slot);
    }

    @Override
    public String info() {
        int n = 0;
        for (int i = 0; i < 36; i++) if (mc.player != null && mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n++;
        return n + " left";
    }
}

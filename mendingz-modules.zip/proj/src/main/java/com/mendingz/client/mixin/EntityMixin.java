package com.mendingz.client.mixin;

import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.modules.combat.Hitboxes;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void mendingz$margin(CallbackInfoReturnable<Float> cir) {
        Hitboxes h = ModuleManager.get(Hitboxes.class);
        if (h != null && h.enabled && (Object) this instanceof PlayerEntity
            && (Object) this != MinecraftClient.getInstance().player) {
            cir.setReturnValue(cir.getReturnValue() + (float) h.expand.value);
        }
    }
}

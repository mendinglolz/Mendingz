package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public class BlockHighlight extends Module {
    private final Setting.Color color = add(new Setting.Color("Color", 0xE5173F));
    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));

    public BlockHighlight() {
        super("BlockHighlight", Category.RENDER, -1);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        if (!(mc.crosshairTarget instanceof BlockHitResult b) || b.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = b.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        Box box = st.getOutlineShape(mc.world, pos).isEmpty() ? new Box(pos)
            : st.getOutlineShape(mc.world, pos).getBoundingBox().offset(pos);
        int[] r = Projector.box(box);
        if (r != null) Draw.box(ctx, r, color.rgb, fill.value ? 50 : 0);
    }
}

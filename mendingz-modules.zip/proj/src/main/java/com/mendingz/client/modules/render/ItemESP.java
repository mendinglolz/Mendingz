package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class ItemESP extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 48, 8, 128, 4));
    private final Setting.Color color = add(new Setting.Color("Color", 0xFFD02B));
    private final Setting.Bool labels = add(new Setting.Bool("Labels", true));

    public ItemESP() {
        super("ItemESP", Category.RENDER, -1);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        Box area = mc.player.getBoundingBox().expand(range.value);
        int tags = 0;
        for (ItemEntity e : mc.world.getEntitiesByClass(ItemEntity.class, area, i -> true)) {
            Vec3d pos = e.getLerpedPos(td);
            Box b = e.getBoundingBox().offset(pos.x - e.getX(), pos.y - e.getY(), pos.z - e.getZ()).expand(0.1);
            int[] r = Projector.box(b);
            if (r == null) continue;
            Draw.box(ctx, r, color.rgb, 40);
            if (labels.value && tags++ < 8) {
                String n = e.getStack().getName().getString() + " x" + e.getStack().getCount();
                Draw.tag(ctx, new String[] {n}, (r[0] + r[2]) / 2, r[1] - 3, color.rgb);
            }
        }
    }
}

package com.mendingz.client.module;

public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public double ratio() {
            return (value - min) / (max - min);
        }

        public void setFromRatio(double t) {
            double raw = min + Math.max(0, Math.min(1, t)) * (max - min);
            value = Math.max(min, Math.min(max, Math.round(raw / step) * step));
        }

        public String display() {
            if (step >= 1) return String.valueOf((int) value);
            if (step >= 0.1) return String.format("%.1f", value);
            return String.format("%.2f", value);
        }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;

        public Mode(String name, int index, String... modes) {
            super(name);
            this.index = index;
            this.modes = modes;
        }

        public String get() {
            return modes[index];
        }

        public void next() {
            index = (index + 1) % modes.length;
        }
    }

    public static class Color extends Setting {
        public static final int[] PALETTE = {
            0xE5173F, 0xFF8A2B, 0xFFB020, 0xFFD02B, 0x7CFF3B, 0x2BDCB0,
            0x2BC4FF, 0x2B7BFF, 0xA63BFF, 0xC78BFF, 0xFF3BD9, 0xFFFFFF
        };
        public int rgb;

        public Color(String name, int rgb) {
            super(name);
            this.rgb = rgb;
        }

        public int argb() {
            return 0xFF000000 | rgb;
        }

        public void cycle(int dir) {
            int best = 0;
            for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == rgb) best = i;
            rgb = PALETTE[(best + dir + PALETTE.length) % PALETTE.length];
        }
    }
}

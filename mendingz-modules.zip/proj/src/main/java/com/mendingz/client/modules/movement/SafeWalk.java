package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/** Sneaks automatically at block edges so you cannot walk off. */
public class SafeWalk extends Module {
    private boolean forced;

    public SafeWalk() {
        super("SafeWalk", Category.MOVEMENT, -1);
    }

    @Override
    protected void onDisable() {
        if (forced) KeyBinding.updatePressedStates();
        forced = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean edge = mc.currentScreen == null && Edge.wouldFall(mc, false);
        if (edge) {
            mc.options.sneakKey.setPressed(true);
            forced = true;
        } else if (forced) {
            forced = false;
            KeyBinding.updatePressedStates();
        }
    }
}

package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class Sneak extends Module {
    public Sneak() {
        super("Sneak", Category.MOVEMENT, GLFW.GLFW_KEY_Z);
    }

    @Override
    protected void onDisable() {
        KeyBinding.updatePressedStates();
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        if (mc.currentScreen == null) mc.options.sneakKey.setPressed(true);
    }
}

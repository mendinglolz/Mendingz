package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Inv;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** Equips the best armor pieces from your inventory. Ranked by material, then durability. */
public class AutoArmor extends Module {
    private final Setting.Num delayMin = add(new Setting.Num("Delay Min (ticks)", 4, 1, 20, 1));
    private final Setting.Num delayMax = add(new Setting.Num("Delay Max (ticks)", 9, 1, 20, 1));
    private int wait;

    private static final String[] PARTS = {"_helmet", "_chestplate", "_leggings", "_boots"};
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public AutoArmor() {
        super("AutoArmor", Category.COMBAT, -1);
    }

    private static int part(ItemStack s) {
        if (s.isEmpty()) return -1;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        for (int i = 0; i < PARTS.length; i++) if (id.endsWith(PARTS[i])) return i;
        return -1;
    }

    private static double score(ItemStack s) {
        if (s.isEmpty()) return -1;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        double tier = id.startsWith("netherite") ? 6 : id.startsWith("diamond") ? 5 : id.startsWith("iron") ? 4
            : id.startsWith("turtle") ? 3.5 : id.startsWith("chainmail") ? 3 : id.startsWith("golden") ? 2.5
            : id.startsWith("copper") ? 2 : 1;
        double dur = s.getMaxDamage() > 0 ? (double) (s.getMaxDamage() - s.getDamage()) / s.getMaxDamage() : 1;
        return tier * 10 + dur;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (wait-- > 0) return;
        wait = Rand.range(delayMin.value, delayMax.value);
        if (!mc.player.currentScreenHandler.getCursorStack().isEmpty()) return;

        for (int slot = 0; slot < 4; slot++) {
            double best = score(mc.player.getEquippedStack(SLOTS[slot]));
            int from = -1;
            for (int i = 0; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (part(s) == slot && score(s) > best) {
                    best = score(s);
                    from = i;
                }
            }
            if (from == -1) continue;
            int armorSlot = 5 + slot;
            boolean empty = mc.player.getEquippedStack(SLOTS[slot]).isEmpty();
            Inv.click(Inv.handlerSlot(from), 0, SlotActionType.PICKUP);
            Inv.click(armorSlot, 0, SlotActionType.PICKUP);
            if (!empty) Inv.click(Inv.handlerSlot(from), 0, SlotActionType.PICKUP);
            return; // one piece per cycle
        }
    }
}

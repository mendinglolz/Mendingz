package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

/** Detaches the camera. Your player stands still (movement keys are blocked) while the camera flies. */
public class Freecam extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.2, 5.0, 0.1));
    private OtherClientPlayerEntity cam;
    private Vec3d eye = Vec3d.ZERO;
    private long last;

    public Freecam() {
        super("Freecam", Category.RENDER, -1);
    }

    @Override
    protected void onEnable() {
        if (mc.player == null || mc.world == null) {
            enabled = false;
            return;
        }
        cam = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "Freecam"));
        eye = mc.player.getEyePos();
        last = System.nanoTime();
        place();
        mc.setCameraEntity(cam);
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.setCameraEntity(mc.player);
        cam = null;
        KeyBinding.updatePressedStates();
    }

    private void place() {
        cam.setPosition(eye.x, eye.y - 1.62, eye.z);
        cam.setYaw(mc.player.getYaw());
        cam.setPitch(mc.player.getPitch());
    }

    /** Stops the real player from moving while the camera is detached. */
    @Override
    public void onPreTick(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
    }

    /** Runs every frame so the camera moves smoothly. */
    @Override
    public void onHud(DrawContext ctx, float td) {
        if (cam == null) return;
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - last) / 1e9);
        last = now;
        if (mc.currentScreen == null) {
            long w = mc.getWindow().getHandle();
            double f = (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS ? 1 : 0)
                - (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS ? 1 : 0);
            double s = (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS ? 1 : 0)
                - (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS ? 1 : 0);
            double v = (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS ? 1 : 0)
                - (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS ? 1 : 0);
            double yaw = Math.toRadians(mc.player.getYaw());
            double pitch = Math.toRadians(mc.player.getPitch());
            double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
            double rx = Math.cos(yaw), rz = Math.sin(yaw);
            double sp = speed.value * 10.0 * dt;
            eye = eye.add((fx * f + rx * s) * sp, fy * f * sp + v * sp, (fz * f + rz * s) * sp);
        }
        place();
    }
}

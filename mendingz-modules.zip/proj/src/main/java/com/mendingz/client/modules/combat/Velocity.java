package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Scales the knockback you take. Works by comparing velocity before and after the hit. */
public class Velocity extends Module {
    private final Setting.Num horizontal = add(new Setting.Num("Horizontal %", 80, 0, 100, 1));
    private final Setting.Num vertical = add(new Setting.Num("Vertical %", 100, 0, 100, 1));
    private Vec3d prev = Vec3d.ZERO;
    private boolean handled;

    public Velocity() {
        super("Velocity", Category.COMBAT, GLFW.GLFW_KEY_V);
    }

    @Override
    protected void onEnable() {
        prev = Vec3d.ZERO;
        handled = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.hurtTime == 0) handled = false;
        if (p.hurtTime > 0 && !handled && p.hurtTime >= p.maxHurtTime - 1) {
            Vec3d v = p.getVelocity();
            Vec3d d = v.subtract(prev);
            if (d.horizontalLength() > 0.05 || Math.abs(d.y) > 0.05) {
                p.setVelocity(prev.x + d.x * horizontal.value / 100.0, prev.y + d.y * vertical.value / 100.0,
                    prev.z + d.z * horizontal.value / 100.0);
            }
            handled = true;
        }
        prev = p.getVelocity();
    }

    @Override
    public String info() {
        return (int) horizontal.value + "%/" + (int) vertical.value + "%";
    }
}

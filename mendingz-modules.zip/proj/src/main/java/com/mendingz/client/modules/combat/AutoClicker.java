package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Friends;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public class AutoClicker extends Module {
    private final Setting.Num minCps = add(new Setting.Num("Min CPS", 8, 1, 20, 1));
    private final Setting.Num maxCps = add(new Setting.Num("Max CPS", 12, 1, 20, 1));
    private final Setting.Bool hold = add(new Setting.Bool("Hold LMB", false));
    private final Setting.Bool jitter = add(new Setting.Bool("Jitter", false));
    private final Setting.Bool skipFriends = add(new Setting.Bool("Skip Friends", true));
    private long next;

    public AutoClicker() {
        super("AutoClicker", Category.COMBAT, GLFW.GLFW_KEY_R);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        if (hold.value && !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity) || !target.isAlive()) return;
        if (skipFriends.value && target instanceof PlayerEntity p && Friends.isFriend(p.getName().getString())) return;
        if (Criticals.holdClicks(mc)) return;

        long now = System.currentTimeMillis();
        if (now < next) return;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (jitter.value) {
            mc.player.setYaw(mc.player.getYaw() + (float) (Rand.d() - 0.5) * 1.2f);
            mc.player.setPitch(mc.player.getPitch() + (float) (Rand.d() - 0.5) * 0.8f);
        }
        double lo = Math.min(minCps.value, maxCps.value), hi = Math.max(minCps.value, maxCps.value);
        double cps = lo + Rand.d() * (hi - lo);
        next = now + (long) (1000.0 / cps * (0.9 + Rand.d() * 0.2));
    }
}

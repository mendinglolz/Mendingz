package com.mendingz.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public enum Category {
        COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), UTILITY("Utility"), CONFIG("Config");

        public final String label;

        Category(String label) {
            this.label = label;
        }
    }

    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public static boolean silent;

    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    public int key; // GLFW key code, -1 = unbound
    public boolean enabled;
    public boolean expanded;
    boolean keyDown;

    public Module(String name, Category category, int key, Setting... settings) {
        this.name = name;
        this.category = category;
        this.key = key;
        this.settings.addAll(List.of(settings));
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
        if (!silent && ModuleManager.NOTIFICATIONS.value && mc.player != null && mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(
                Text.literal("\u00a7c[Mendingz] \u00a7f" + name + (value ? " \u00a7aenabled" : " \u00a77disabled")));
        }
    }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Start of client tick, player and world exist. */
    public void onPreTick(MinecraftClient mc) {}

    /** End of client tick, player and world exist. */
    public void onTick(MinecraftClient mc) {}

    /** End of client tick, even when not in a world. */
    public void onAlwaysTick(MinecraftClient mc) {}

    /** Every HUD frame while a world is loaded. */
    public void onHud(DrawContext ctx, float tickDelta) {}

    /** Text shown after the name in the module list, or null. */
    public String info() {
        return null;
    }
}

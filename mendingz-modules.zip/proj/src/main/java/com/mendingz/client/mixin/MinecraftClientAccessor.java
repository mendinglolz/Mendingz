package com.mendingz.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int mendingz$getItemUseCooldown();

    @Accessor("itemUseCooldown")
    void mendingz$setItemUseCooldown(int value);
}

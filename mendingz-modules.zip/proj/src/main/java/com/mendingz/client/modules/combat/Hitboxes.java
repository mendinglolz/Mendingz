package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import org.lwjgl.glfw.GLFW;

/** Expands the targeting hitbox of other players. The work is done in EntityMixin. */
public class Hitboxes extends Module {
    public final Setting.Num expand = add(new Setting.Num("Expand", 0.1, 0.0, 0.5, 0.05));

    public Hitboxes() {
        super("Hitboxes", Category.COMBAT, GLFW.GLFW_KEY_B);
    }

    @Override
    public String info() {
        return String.format("%.2f", expand.value);
    }
}

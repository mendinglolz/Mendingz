package com.mendingz.client.modules.utility;

import com.mendingz.client.module.Module;
import com.mendingz.client.util.Friends;

/** While enabled, players on your friends list are skipped by combat modules and drawn differently. Manage with /mz friend. */
public class FriendsModule extends Module {
    public FriendsModule() {
        super("Friends", Category.UTILITY, -1);
        enabled = true;
    }

    @Override
    public String info() {
        return String.valueOf(Friends.NAMES.size());
    }
}

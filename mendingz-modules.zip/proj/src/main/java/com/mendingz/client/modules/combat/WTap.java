package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.EntityHitResult;

/** Briefly releases forward right after you attack, which resets sprint. */
public class WTap extends Module {
    private final Setting.Num minTicks = add(new Setting.Num("Min Ticks", 1, 1, 4, 1));
    private final Setting.Num maxTicks = add(new Setting.Num("Max Ticks", 2, 1, 4, 1));
    private boolean attackWas;
    private int ticks;

    public WTap() {
        super("WTap", Category.COMBAT, -1);
    }

    @Override
    protected void onDisable() {
        ticks = 0;
        KeyBinding.updatePressedStates();
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        if (ticks > 0) {
            mc.options.forwardKey.setPressed(false);
            mc.player.setSprinting(false);
            if (--ticks == 0) KeyBinding.updatePressedStates();
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean attack = mc.options.attackKey.isPressed();
        if (attack && !attackWas && mc.player.isSprinting() && mc.crosshairTarget instanceof EntityHitResult) {
            ticks = Rand.range(minTicks.value, maxTicks.value);
        }
        attackWas = attack;
    }
}

package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.BlockScanner;
import com.mendingz.client.util.Draw;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Highlights blocks that usually mean a player base. Each category has its own toggle and color. */
public class BaseFinder extends Module {
    private static final String[] NAMES = {"Chest", "Hopper", "Shulker Box", "Bed", "Amethyst Cluster", "Crafter",
        "Redstone", "Furnace", "Farm Blocks", "Unnatural Block"};
    private static final int[] DEFAULT_COLORS = {0xFFB020, 0xE5173F, 0xFF3BD9, 0x7CFF3B, 0xC78BFF, 0x2BC4FF,
        0xFF3B3B, 0xFFD02B, 0x3DDC57, 0xFF8A2B};
    private static final boolean[] DEFAULT_ON = {true, true, true, false, true, true, true, true, false, true};

    private final Setting.Num range = add(new Setting.Num("Range", 96, 32, 192, 16));
    private final Setting.Num minPerChunk = add(new Setting.Num("Min Per Chunk", 1, 1, 10, 1));
    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    private final Setting.Bool tags = add(new Setting.Bool("Tags", true));
    private final Setting.Bool panel = add(new Setting.Bool("Info Panel", true));
    private final Setting.Bool[] on = new Setting.Bool[NAMES.length];
    private final Setting.Color[] colors = new Setting.Color[NAMES.length];
    private final Map<Block, Integer> blockCat = new HashMap<>();
    private final BlockScanner scanner;
    private List<BlockScanner.Hit> hits = List.of();

    public BaseFinder() {
        super("BaseFinder", Category.RENDER, -1);
        for (int i = 0; i < NAMES.length; i++) {
            on[i] = add(new Setting.Bool(NAMES[i], DEFAULT_ON[i]));
            colors[i] = add(new Setting.Color(NAMES[i] + " Color", DEFAULT_COLORS[i]));
        }
        for (Block b : Registries.BLOCK) {
            int c = categorize(Registries.BLOCK.getId(b).getPath());
            if (c >= 0) blockCat.put(b, c);
        }
        scanner = new BlockScanner(st -> blockCat.getOrDefault(st.getBlock(), -1));
    }

    private static int categorize(String p) {
        if (p.equals("chest") || p.equals("trapped_chest") || p.equals("barrel")) return 0;
        if (p.equals("hopper") || p.equals("dropper") || p.equals("dispenser")) return 1;
        if (p.endsWith("shulker_box")) return 2;
        if (p.endsWith("_bed")) return 3;
        if (p.equals("amethyst_cluster") || p.equals("budding_amethyst") || p.endsWith("_amethyst_bud")) return 4;
        if (p.equals("crafter")) return 5;
        if (p.equals("redstone_wire") || p.equals("repeater") || p.equals("comparator") || p.equals("observer")
            || p.equals("piston") || p.equals("sticky_piston") || p.equals("redstone_lamp")
            || p.equals("daylight_detector") || p.equals("tnt")) return 6;
        if (p.equals("furnace") || p.equals("blast_furnace") || p.equals("smoker")) return 7;
        if (p.equals("farmland") || p.equals("composter")) return 8;
        if (p.endsWith("concrete") || p.endsWith("concrete_powder") || p.endsWith("glazed_terracotta")
            || p.endsWith("stained_glass") || p.equals("glass") || p.equals("crafting_table") || p.equals("beacon")
            || p.equals("enchanting_table") || p.equals("anvil") || p.equals("jukebox") || p.equals("note_block")
            || p.equals("lectern") || p.equals("bookshelf") || p.endsWith("_wool")) return 9;
        return -1;
    }

    @Override
    protected void onDisable() {
        scanner.clear();
        hits = List.of();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        scanner.tick(mc, (int) range.value, 2, 100);
        List<BlockScanner.Hit> list = Finders.collect(scanner, range.value, c -> on[c].value);
        if (minPerChunk.value > 1) {
            Map<Long, Integer> counts = new HashMap<>();
            for (BlockScanner.Hit h : list) counts.merge(((long) (h.pos.getX() >> 4) << 40) ^ ((long) (h.pos.getZ() >> 4) << 8) ^ h.cat, 1, Integer::sum);
            list.removeIf(h -> counts.get(((long) (h.pos.getX() >> 4) << 40) ^ ((long) (h.pos.getZ() >> 4) << 8) ^ h.cat) < minPerChunk.value);
        }
        hits = list;
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        Finders.draw(ctx, hits, c -> colors[c].rgb, NAMES, fill.value, tags.value, 150, 6);
        if (!panel.value) return;

        Vec3d me = mc.player.getPos();
        int w = 150, h = hits.isEmpty() ? 28 : 54;
        ctx.fill(4, 24, 4 + w, 24 + h, Draw.BG);
        ctx.fill(4, 24, 6, 24 + h, 0xFFE5173F);
        ctx.drawText(mc.textRenderer, "Base Finder", 10, 28, 0xFFFFFFFF, true);
        String n = hits.size() + " nearby";
        ctx.drawText(mc.textRenderer, n, 4 + w - mc.textRenderer.getWidth(n) - 4, 28, 0xFFB5B5BE, true);
        if (!hits.isEmpty()) {
            BlockScanner.Hit near = hits.get(0);
            ctx.drawText(mc.textRenderer, NAMES[near.cat], 10, 40, 0xFF000000 | colors[near.cat].rgb, true);
            String c = near.pos.getX() + " " + near.pos.getY() + " " + near.pos.getZ() + "  "
                + (int) Math.sqrt(near.pos.getSquaredDistance(me)) + "m";
            ctx.drawText(mc.textRenderer, c, 10, 52, 0xFFFFFFFF, true);
        }
    }

    @Override
    public String info() {
        return String.valueOf(hits.size());
    }
}

package com.mendingz.client.gui;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * Draws the PNG icons from assets/mendingz/textures/gui/icon.
 * If your Minecraft version rejects the drawTexture call below, this is the only place to fix.
 */
public final class Icons {
    private static final Map<String, Identifier> CACHE = new HashMap<>();

    private Icons() {}

    private static Identifier id(String name) {
        return CACHE.computeIfAbsent(name, n -> Identifier.of("mendingz", "textures/gui/icon/" + n + ".png"));
    }

    /** Module or tab icon (24x24 texture) drawn at size x size GUI pixels. */
    public static void draw(DrawContext ctx, String name, int x, int y, int size) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id(name.toLowerCase()), x, y, 0f, 0f, size, size, 24, 24, 24, 24);
    }

    public static void logo(DrawContext ctx, int x, int y, int size) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id("logo"), x, y, 0f, 0f, size, size, 32, 32, 32, 32);
    }
}

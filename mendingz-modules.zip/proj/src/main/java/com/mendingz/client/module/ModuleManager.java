package com.mendingz.client.module;

import com.mendingz.client.module.Module.Category;
import com.mendingz.client.modules.combat.*;
import com.mendingz.client.modules.movement.*;
import com.mendingz.client.modules.render.*;
import com.mendingz.client.modules.utility.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static final Setting.Bool SHOW_HUD = new Setting.Bool("Show HUD", true);
    public static final Setting.Bool SHOW_MODULE_LIST = new Setting.Bool("Module List", true);
    public static final Setting.Bool SHOW_INFO = new Setting.Bool("Info Pills", true);
    public static final Setting.Bool NOTIFICATIONS = new Setting.Bool("Notifications", true);
    public static final List<Setting> CONFIG = List.of(SHOW_HUD, SHOW_MODULE_LIST, SHOW_INFO, NOTIFICATIONS);

    private ModuleManager() {}

    public static void init() {
        // Combat (12)
        MODULES.add(new AutoClicker());
        MODULES.add(new AimAssist());
        MODULES.add(new ReachDisplay());
        MODULES.add(new Velocity());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoTotem());
        MODULES.add(new Hitboxes());
        MODULES.add(new WTap());
        MODULES.add(new Criticals());
        MODULES.add(new AutoArmor());
        MODULES.add(new AutoPotion());
        MODULES.add(new AutoOffhand());
        // Movement (8)
        MODULES.add(new ToggleSprint());
        MODULES.add(new SafeWalk());
        MODULES.add(new BridgeAssist());
        MODULES.add(new Sneak());
        MODULES.add(new FastPlace());
        MODULES.add(new AutoTool());
        MODULES.add(new AntiAFK());
        MODULES.add(new StepAssist());
        // Render (12)
        MODULES.add(new PlayerESP());
        MODULES.add(new Nametags());
        MODULES.add(new Fullbright());
        MODULES.add(new BlockHighlight());
        MODULES.add(new Zoom());
        MODULES.add(new BaseFinder());
        MODULES.add(new OreFinder());
        MODULES.add(new StorageESP());
        MODULES.add(new WaypointsModule());
        MODULES.add(new Freecam());
        MODULES.add(new ItemESP());
        MODULES.add(new Trail());
        // Utility (4 modules; keybinds, panic and profiles are built in)
        MODULES.add(new FriendsModule());
        MODULES.add(new CoordLogger());
        MODULES.add(new AutoReconnect());
        MODULES.add(new SpawnerFinder());
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (m.getClass() == type) return type.cast(m);
        return null;
    }

    public static Module byName(String name) {
        for (Module m : MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    /** Disables everything (End key). */
    public static void panic() {
        Module.silent = true;
        for (Module m : MODULES) m.setEnabled(false);
        Module.silent = false;
    }

    public static void preTick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (!m.enabled) continue;
            try { m.onPreTick(mc); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void hud(DrawContext ctx, float td) {
        for (Module m : MODULES) {
            if (!m.enabled) continue;
            try { m.onHud(ctx, td); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void tick(MinecraftClient mc, long window) {
        // Keybinds (ignored while a screen is open).
        if (mc.currentScreen == null) {
            for (Module m : MODULES) {
                if (m.key == -1) continue;
                boolean down = GLFW.glfwGetKey(window, m.key) == GLFW.GLFW_PRESS;
                if (down && !m.keyDown) m.toggle();
                m.keyDown = down;
            }
        } else {
            for (Module m : MODULES) m.keyDown = m.key != -1 && GLFW.glfwGetKey(window, m.key) == GLFW.GLFW_PRESS;
        }

        for (Module m : MODULES) {
            if (!m.enabled) continue;
            try {
                if (mc.player != null && mc.world != null) m.onTick(mc);
                m.onAlwaysTick(mc);
            } catch (Throwable t) {
                fail(m, t);
            }
        }
    }

    private static void fail(Module m, Throwable t) {
        t.printStackTrace();
        Module.silent = true;
        try { m.setEnabled(false); } catch (Throwable ignored) {}
        Module.silent = false;
    }
}

package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Inv;
import com.mendingz.client.util.Rand;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws (or drinks) a healing potion from your hotbar when health is low. */
public class AutoPotion extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", 8, 1, 20, 1));
    private final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Splash", "Drink"));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown (ticks)", 20, 5, 100, 1));
    private int wait, drinkSlot = -1, prevSlot = -1;

    public AutoPotion() {
        super("AutoPotion", Category.COMBAT, -1);
    }

    @Override
    protected void onDisable() {
        finishDrink();
    }

    private static boolean heals(ItemStack s, boolean splash) {
        if (!s.isOf(splash ? Items.SPLASH_POTION : Items.POTION)) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (StatusEffectInstance e : c.getEffects()) if (e.getEffectType() == StatusEffects.INSTANT_HEALTH) return true;
        return false;
    }

    private void finishDrink() {
        mc.options.useKey.setPressed(false);
        if (prevSlot != -1 && mc.player != null) Inv.select(prevSlot);
        prevSlot = -1;
        drinkSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (drinkSlot != -1) { // drinking in progress
            if (!mc.player.isUsingItem()) finishDrink();
            else mc.options.useKey.setPressed(true);
            return;
        }
        if (wait-- > 0 || mc.currentScreen != null || mc.player.getHealth() > health.value) return;

        boolean splash = mode.index == 0;
        int slot = Inv.findHotbar(s -> heals(s, splash));
        if (slot == -1) return;
        wait = (int) cooldown.value + Rand.range(0, 4);
        prevSlot = Inv.selected();
        Inv.select(slot);

        if (splash) {
            float pitch = mc.player.getPitch();
            mc.player.setPitch(90f);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.setPitch(pitch);
            Inv.select(prevSlot);
            prevSlot = -1;
        } else {
            drinkSlot = slot;
            mc.options.useKey.setPressed(true);
        }
    }
}

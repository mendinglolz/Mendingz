package com.mendingz.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Projects world positions onto the GUI-scaled screen using the camera entity.
 * Used for all ESP drawing, so no world-render API is needed. Assumes first person.
 */
public final class Projector {
    private static double ex, ey, ez, fx, fy, fz, rx, ry, rz, ux, uy, uz, tanHalf;
    private static int w = 1, h = 1;
    private static boolean valid;

    private Projector() {}

    public static void update(MinecraftClient mc, float td, int sw, int sh) {
        Entity cam = mc.getCameraEntity();
        if (cam == null) {
            valid = false;
            return;
        }
        Vec3d p = cam.getLerpedPos(td);
        ex = p.x;
        ey = p.y + cam.getEyeHeight(cam.getPose());
        ez = p.z;
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw);
        ry = 0;
        rz = -Math.sin(yaw);
        // up = right x forward
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
        tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        w = sw;
        h = sh;
        valid = true;
    }

    public static int width() { return w; }
    public static int height() { return h; }
    public static boolean valid() { return valid; }

    /** Returns {x, y} in GUI coordinates, or null when behind the camera. */
    public static double[] project(double x, double y, double z) {
        if (!valid) return null;
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) return null;
        double sx = (dx * rx + dy * ry + dz * rz) / depth;
        double sy = (dx * ux + dy * uy + dz * uz) / depth;
        double aspect = (double) w / h;
        double px = w / 2.0 + (sx / (tanHalf * aspect)) * (w / 2.0);
        double py = h / 2.0 - (sy / tanHalf) * (h / 2.0);
        return new double[] {px, py};
    }

    /** Screen rectangle {x1, y1, x2, y2} of a world box, or null if not visible. */
    public static int[] box(Box b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            double[] p = project((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY,
                (i & 4) == 0 ? b.minZ : b.maxZ);
            if (p == null) return null;
            minX = Math.min(minX, p[0]);
            maxX = Math.max(maxX, p[0]);
            minY = Math.min(minY, p[1]);
            maxY = Math.max(maxY, p[1]);
        }
        if (maxX < 0 || minX > w || maxY < 0 || minY > h) return null;
        if (maxX - minX < 4) { minX -= 2; maxX += 2; }
        if (maxY - minY < 4) { minY -= 2; maxY += 2; }
        return new int[] {(int) minX, (int) minY, (int) maxX, (int) maxY};
    }
}

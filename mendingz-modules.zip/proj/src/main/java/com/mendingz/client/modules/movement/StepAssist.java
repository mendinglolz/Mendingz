package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

public class StepAssist extends Module {
    private final Setting.Num height = add(new Setting.Num("Height", 1.0, 0.6, 2.5, 0.1));

    public StepAssist() {
        super("StepAssist", Category.MOVEMENT, -1);
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(0.6);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(height.value);
    }

    @Override
    public String info() {
        return String.format("%.1f", height.value);
    }
}

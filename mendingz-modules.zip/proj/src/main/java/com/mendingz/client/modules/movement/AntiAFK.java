package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Hand;

public class AntiAFK extends Module {
    private final Setting.Num interval = add(new Setting.Num("Interval (sec)", 25, 5, 120, 1));
    private long next;
    private boolean jumped;

    public AntiAFK() {
        super("AntiAFK", Category.MOVEMENT, -1);
    }

    @Override
    protected void onEnable() {
        next = System.currentTimeMillis() + (long) (interval.value * 1000);
    }

    @Override
    protected void onDisable() {
        if (jumped) KeyBinding.updatePressedStates();
        jumped = false;
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        if (jumped) {
            mc.options.jumpKey.setPressed(false);
            jumped = false;
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        if (now < next || mc.currentScreen != null) return;
        switch (Rand.range(0, 2)) {
            case 0 -> {
                mc.options.jumpKey.setPressed(true);
                jumped = true;
            }
            case 1 -> mc.player.setYaw(mc.player.getYaw() + (float) (Rand.d() - 0.5) * 30f);
            default -> mc.player.swingHand(Hand.MAIN_HAND);
        }
        next = now + (long) (interval.value * 1000 * (0.7 + Rand.d() * 0.6));
    }
}

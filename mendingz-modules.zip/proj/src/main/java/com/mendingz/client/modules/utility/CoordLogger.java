package com.mendingz.client.modules.utility;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Appends your coordinates to config/mendingz/coords.log. */
public class CoordLogger extends Module {
    private final Setting.Num interval = add(new Setting.Num("Interval (sec)", 60, 5, 600, 5));
    private final Setting.Bool onDimension = add(new Setting.Bool("Log Dimension Change", true));
    private long next;
    private String lastDim = "";

    public CoordLogger() {
        super("CoordLogger", Category.UTILITY, -1);
    }

    @Override
    protected void onEnable() {
        next = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        String dim = mc.world.getRegistryKey().getValue().toString();
        long now = System.currentTimeMillis();
        boolean changed = onDimension.value && !dim.equals(lastDim) && !lastDim.isEmpty();
        lastDim = dim;
        if (now < next && !changed) return;
        next = now + (long) (interval.value * 1000);
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("mendingz").resolve("coords.log");
            Files.createDirectories(f.getParent());
            String line = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " | " + dim
                + " | " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ() + System.lineSeparator();
            Files.writeString(f, line, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

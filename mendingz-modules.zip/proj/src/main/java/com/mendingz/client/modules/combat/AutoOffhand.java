package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Inv;
import com.mendingz.client.util.Rand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/** Keeps a totem in the offhand at low health, otherwise your chosen default item. */
public class AutoOffhand extends Module {
    private final Setting.Num totemHealth = add(new Setting.Num("Totem Health", 8, 1, 20, 1));
    private final Setting.Mode normal = add(new Setting.Mode("Default", 0, "Shield", "Gapple", "Totem", "None"));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 4, 1, 20, 1));
    private int wait;

    public AutoOffhand() {
        super("AutoOffhand", Category.COMBAT, -1);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (wait-- > 0 || mc.currentScreen instanceof HandledScreen) return;
        if (!mc.player.currentScreenHandler.getCursorStack().isEmpty()) return;

        Item want = null;
        if (mc.player.getHealth() <= totemHealth.value) want = Items.TOTEM_OF_UNDYING;
        else if (normal.index == 0) want = Items.SHIELD;
        else if (normal.index == 1) want = Items.ENCHANTED_GOLDEN_APPLE;
        else if (normal.index == 2) want = Items.TOTEM_OF_UNDYING;
        if (want == null || mc.player.getOffHandStack().isOf(want)) return;

        final Item w = want;
        int slot = Inv.findInventory(s -> s.isOf(w));
        if (slot == -1 && w == Items.ENCHANTED_GOLDEN_APPLE) slot = Inv.findInventory(s -> s.isOf(Items.GOLDEN_APPLE));
        if (slot == -1) return;
        Inv.swapOffhand(slot);
        wait = (int) delay.value + Rand.range(0, 3);
    }
}

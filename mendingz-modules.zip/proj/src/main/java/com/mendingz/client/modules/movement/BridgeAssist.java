package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.BlockItem;

/** Auto sneak at the edge while backing up with a block in hand and looking down. */
public class BridgeAssist extends Module {
    private final Setting.Num minPitch = add(new Setting.Num("Min Pitch", 60, 0, 90, 5));
    private final Setting.Bool needBlock = add(new Setting.Bool("Holding Block", true));
    private boolean forced;

    public BridgeAssist() {
        super("BridgeAssist", Category.MOVEMENT, -1);
    }

    @Override
    protected void onDisable() {
        if (forced) KeyBinding.updatePressedStates();
        forced = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean active = mc.currentScreen == null && mc.player.getPitch() >= minPitch.value
            && (!needBlock.value || mc.player.getMainHandStack().getItem() instanceof BlockItem)
            && Edge.wouldFall(mc, true);
        if (active) {
            mc.options.sneakKey.setPressed(true);
            forced = true;
        } else if (forced) {
            forced = false;
            KeyBinding.updatePressedStates();
        }
    }
}

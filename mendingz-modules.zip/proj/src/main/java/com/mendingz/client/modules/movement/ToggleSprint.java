package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class ToggleSprint extends Module {
    public ToggleSprint() {
        super("ToggleSprint", Category.MOVEMENT, GLFW.GLFW_KEY_L);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        boolean canSprint = mc.player.getHungerManager().getFoodLevel() > 6 || mc.player.getAbilities().allowFlying;
        if (mc.options.forwardKey.isPressed() && !mc.player.isSneaking() && !mc.player.horizontalCollision
            && !mc.player.isUsingItem() && canSprint) {
            mc.player.setSprinting(true);
        }
    }
}

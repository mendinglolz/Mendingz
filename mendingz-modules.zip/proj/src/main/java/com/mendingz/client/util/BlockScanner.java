package com.mendingz.client.util;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;

/** Incrementally scans loaded chunks for blocks a classifier cares about (-1 = ignore). */
public final class BlockScanner {
    public static final class Hit {
        public final BlockPos pos;
        public final int cat;
        public final BlockState state;

        Hit(BlockPos pos, int cat, BlockState state) {
            this.pos = pos;
            this.cat = cat;
            this.state = state;
        }
    }

    private final ToIntFunction<BlockState> classifier;
    private final Map<Long, List<Hit>> results = new HashMap<>();
    private final Map<Long, Integer> scanned = new HashMap<>();
    private int tickCount;

    public BlockScanner(ToIntFunction<BlockState> classifier) {
        this.classifier = classifier;
    }

    public void clear() {
        results.clear();
        scanned.clear();
    }

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }

    public void tick(MinecraftClient mc, int radiusBlocks, int perTick, int rescanTicks) {
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) {
            clear();
            return;
        }
        tickCount++;
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        int r = (radiusBlocks >> 4) + 1;

        results.keySet().removeIf(k -> Math.abs((int) (k >> 32) - pcx) > r + 1 || Math.abs((int) (long) k - pcz) > r + 1);
        scanned.keySet().removeIf(k -> Math.abs((int) (k >> 32) - pcx) > r + 1 || Math.abs((int) (long) k - pcz) > r + 1);

        List<long[]> candidates = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                long k = key(pcx + dx, pcz + dz);
                Integer last = scanned.get(k);
                if (last != null && tickCount - last < rescanTicks) continue;
                candidates.add(new long[] {last == null ? 0 : 1, (long) dx * dx + (long) dz * dz, k});
            }
        }
        candidates.sort((a, b) -> a[0] != b[0] ? Long.compare(a[0], b[0]) : Long.compare(a[1], b[1]));
        for (int i = 0; i < Math.min(perTick, candidates.size()); i++) {
            long k = candidates.get(i)[2];
            scanned.put(k, tickCount);
            List<Hit> hits = scanChunk(world, (int) (k >> 32), (int) k);
            if (hits != null) results.put(k, hits);
        }
    }

    private List<Hit> scanChunk(ClientWorld world, int cx, int cz) {
        WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz);
        if (chunk == null) return null;
        List<Hit> hits = new ArrayList<>();
        ChunkSection[] sections = chunk.getSectionArray();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection s = sections[i];
            if (s == null || s.isEmpty() || !s.hasAny(st -> classifier.applyAsInt(st) >= 0)) continue;
            int baseY = (chunk.getBottomSectionCoord() + i) << 4;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        BlockState st = s.getBlockState(x, y, z);
                        int cat = classifier.applyAsInt(st);
                        if (cat >= 0) hits.add(new Hit(new BlockPos(cx * 16 + x, baseY + y, cz * 16 + z), cat, st));
                    }
                }
            }
        }
        return hits;
    }

    public void forEach(Consumer<Hit> c) {
        for (List<Hit> list : results.values()) for (Hit h : list) c.accept(h);
    }
}

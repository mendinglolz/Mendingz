package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.BlockScanner;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

public class StorageESP extends Module {
    private static final String[] NAMES = {"Chest", "Barrel", "Ender Chest", "Shulker Box"};
    private final Setting.Num range = add(new Setting.Num("Range", 64, 16, 128, 8));
    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    private final Setting.Color chest = add(new Setting.Color("Chest Color", 0xFFB020));
    private final Setting.Color barrel = add(new Setting.Color("Barrel Color", 0xFF8A2B));
    private final Setting.Color ender = add(new Setting.Color("Ender Chest Color", 0xA63BFF));
    private final Setting.Color shulker = add(new Setting.Color("Shulker Color", 0xFF3BD9));
    private final BlockScanner scanner = new BlockScanner(st -> {
        if (st.isOf(Blocks.CHEST) || st.isOf(Blocks.TRAPPED_CHEST)) return 0;
        if (st.isOf(Blocks.BARREL)) return 1;
        if (st.isOf(Blocks.ENDER_CHEST)) return 2;
        String p = net.minecraft.registry.Registries.BLOCK.getId(st.getBlock()).getPath();
        return p.endsWith("shulker_box") ? 3 : -1;
    });
    private List<BlockScanner.Hit> hits = List.of();

    public StorageESP() {
        super("StorageESP", Category.RENDER, -1);
    }

    @Override
    protected void onDisable() {
        scanner.clear();
        hits = List.of();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        scanner.tick(mc, (int) range.value, 2, 100);
        hits = Finders.collect(scanner, range.value, c -> true);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        Finders.draw(ctx, hits, c -> c == 0 ? chest.rgb : c == 1 ? barrel.rgb : c == 2 ? ender.rgb : shulker.rgb,
            NAMES, fill.value, false, 150, 0);
    }

    @Override
    public String info() {
        return String.valueOf(hits.size());
    }
}

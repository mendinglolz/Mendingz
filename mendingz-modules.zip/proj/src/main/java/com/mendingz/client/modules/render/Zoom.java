package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Lowers the FOV option while active. The game limits FOV to 30 at minimum. */
public class Zoom extends Module {
    private final Setting.Num factor = add(new Setting.Num("Zoom", 3.0, 1.5, 6.0, 0.5));
    private final Setting.Bool holdMode = add(new Setting.Bool("Hold Key", true));
    private int baseFov = -1;

    public Zoom() {
        super("Zoom", Category.RENDER, GLFW.GLFW_KEY_C);
    }

    @Override
    protected void onEnable() {
        baseFov = mc.options.getFov().getValue();
    }

    @Override
    protected void onDisable() {
        if (baseFov != -1) mc.options.getFov().setValue(baseFov);
        baseFov = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (holdMode.value && key != -1 && GLFW.glfwGetKey(mc.getWindow().getHandle(), key) != GLFW.GLFW_PRESS) {
            setEnabled(false);
            return;
        }
        if (baseFov == -1) baseFov = mc.options.getFov().getValue();
        int target = (int) Math.max(30, Math.min(110, baseFov / factor.value));
        if (mc.options.getFov().getValue() != target) mc.options.getFov().setValue(target);
    }
}

package com.mendingz.client.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mendingz.client.module.Module;
import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Config profiles: JSON files in .minecraft/config/mendingz/profiles. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {}

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("mendingz").resolve("profiles");
    }

    private static void write(Setting s, JsonObject o) {
        if (s instanceof Setting.Bool b) o.addProperty(s.name, b.value);
        else if (s instanceof Setting.Num n) o.addProperty(s.name, n.value);
        else if (s instanceof Setting.Mode m) o.addProperty(s.name, m.index);
        else if (s instanceof Setting.Color c) o.addProperty(s.name, c.rgb);
    }

    private static void read(Setting s, JsonObject o) {
        if (!o.has(s.name)) return;
        if (s instanceof Setting.Bool b) b.value = o.get(s.name).getAsBoolean();
        else if (s instanceof Setting.Num n) n.value = o.get(s.name).getAsDouble();
        else if (s instanceof Setting.Mode m) m.index = Math.max(0, Math.min(m.modes.length - 1, o.get(s.name).getAsInt()));
        else if (s instanceof Setting.Color c) c.rgb = o.get(s.name).getAsInt();
    }

    public static boolean save(String name) {
        try {
            JsonObject root = new JsonObject();
            JsonObject mods = new JsonObject();
            for (Module m : ModuleManager.MODULES) {
                JsonObject mo = new JsonObject();
                mo.addProperty("key", m.key);
                JsonObject so = new JsonObject();
                for (Setting s : m.settings) write(s, so);
                mo.add("settings", so);
                mods.add(m.name, mo);
            }
            root.add("modules", mods);
            JsonObject cfg = new JsonObject();
            for (Setting s : ModuleManager.CONFIG) write(s, cfg);
            root.add("config", cfg);
            Files.createDirectories(dir());
            Files.writeString(dir().resolve(name + ".json"), GSON.toJson(root));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean load(String name) {
        try {
            Path f = dir().resolve(name + ".json");
            if (!Files.exists(f)) return false;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            JsonObject mods = root.getAsJsonObject("modules");
            for (Module m : ModuleManager.MODULES) {
                if (mods == null || !mods.has(m.name)) continue;
                JsonObject mo = mods.getAsJsonObject(m.name);
                if (mo.has("key")) m.key = mo.get("key").getAsInt();
                if (mo.has("settings")) for (Setting s : m.settings) read(s, mo.getAsJsonObject("settings"));
            }
            if (root.has("config")) for (Setting s : ModuleManager.CONFIG) read(s, root.getAsJsonObject("config"));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.exists(dir()) ? Files.list(dir()) : Stream.<Path>empty()) {
            s.forEach(p -> {
                String n = p.getFileName().toString();
                if (n.endsWith(".json")) out.add(n.substring(0, n.length() - 5));
            });
        } catch (Exception ignored) {
        }
        return out;
    }
}

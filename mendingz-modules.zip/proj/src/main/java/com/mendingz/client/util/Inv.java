package com.mendingz.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

import java.util.function.Predicate;

public final class Inv {
    private Inv() {}

    public static int findHotbar(Predicate<ItemStack> p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }

    /** Index 0-8 hotbar, 9-35 main inventory. */
    public static int findInventory(Predicate<ItemStack> p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (int i = 0; i < 36; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }

    public static int selected() {
        return MinecraftClient.getInstance().player.getInventory().getSelectedSlot();
    }

    public static void select(int slot) {
        MinecraftClient.getInstance().player.getInventory().setSelectedSlot(slot);
    }

    /** Converts an inventory index into a slot id of the player screen handler. */
    public static int handlerSlot(int inv) {
        return inv < 9 ? 36 + inv : inv;
    }

    public static void click(int slot, int button, SlotActionType type) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, button, type, mc.player);
    }

    /** Swaps the given inventory index with the offhand. */
    public static void swapOffhand(int invIndex) {
        click(handlerSlot(invIndex), 40, SlotActionType.SWAP);
    }
}

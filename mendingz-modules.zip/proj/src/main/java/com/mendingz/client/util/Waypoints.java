package com.mendingz.client.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Waypoints {
    public static final class Point {
        public String name;
        public String dim;
        public int x, y, z;
    }

    public static final List<Point> LIST = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Waypoints() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("mendingz").resolve("waypoints.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            List<Point> read = GSON.fromJson(Files.readString(f), new TypeToken<List<Point>>() {}.getType());
            if (read != null) {
                LIST.clear();
                LIST.addAll(read);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(LIST));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean remove(String name) {
        boolean r = LIST.removeIf(p -> p.name.equalsIgnoreCase(name));
        if (r) save();
        return r;
    }
}

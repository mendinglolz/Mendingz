package com.mendingz.client.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Box;

/** Shared edge detection for SafeWalk and BridgeAssist. */
final class Edge {
    private Edge() {}

    /** True when the player is trying to walk and the spot they would step onto has no floor. */
    static boolean wouldFall(MinecraftClient mc, boolean onlyBackward) {
        if (!mc.player.isOnGround()) return false;
        double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (onlyBackward && f >= 0) return false;
        if (f == 0 && s == 0) return false;
        double yaw = Math.toRadians(mc.player.getYaw());
        double dx = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * 0.3;
        double dz = (Math.cos(yaw) * f + Math.sin(yaw) * s) * 0.3;
        Box b = mc.player.getBoundingBox().offset(dx, -0.6, dz);
        return mc.world.isSpaceEmpty(mc.player, b);
    }
}

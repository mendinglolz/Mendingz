package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Friends;
import com.mendingz.client.util.Projector;
import com.mendingz.client.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Nametags extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 64, 16, 256, 8));
    private final Setting.Bool health = add(new Setting.Bool("Health", true));
    private final Setting.Bool armor = add(new Setting.Bool("Armor", true));
    private final Setting.Bool distance = add(new Setting.Bool("Distance", true));

    public Nametags() {
        super("Nametags", Category.RENDER, -1);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        for (PlayerEntity p : Targets.players(mc, range.value, true)) {
            Vec3d pos = p.getLerpedPos(td);
            double[] s = Projector.project(pos.x, pos.y + p.getHeight() + 0.35, pos.z);
            if (s == null) continue;
            StringBuilder sb = new StringBuilder();
            if (health.value) sb.append(Math.round(p.getHealth() + p.getAbsorptionAmount())).append(" HP  ");
            if (armor.value) sb.append("Armor ").append(p.getArmor()).append("  ");
            if (distance.value) sb.append((int) mc.player.distanceTo(p)).append("m");
            boolean friend = Friends.isFriend(p.getName().getString());
            String[] lines = sb.length() == 0 ? new String[] {p.getName().getString()}
                : new String[] {p.getName().getString(), sb.toString().trim()};
            Draw.tag(ctx, lines, (int) s[0], (int) s[1], friend ? 0x7CFF3B : 0xE5173F);
        }
    }
}

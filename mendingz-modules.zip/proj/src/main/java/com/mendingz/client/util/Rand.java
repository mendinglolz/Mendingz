package com.mendingz.client.util;

import java.util.concurrent.ThreadLocalRandom;

public final class Rand {
    private Rand() {}

    public static double d() {
        return ThreadLocalRandom.current().nextDouble();
    }

    public static int range(double a, double b) {
        int lo = (int) Math.min(a, b), hi = (int) Math.max(a, b);
        return lo + ThreadLocalRandom.current().nextInt(hi - lo + 1);
    }
}

package com.mendingz.client.gui;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.util.Cps;
import com.mendingz.client.util.Projector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class MendingzHud {
    private static final int ACCENT = 0xFFE5173F;

    private MendingzHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !ModuleManager.SHOW_HUD.value) return;
        TextRenderer tr = mc.textRenderer;

        if (mc.world != null && mc.player != null) {
            float td = tickCounter.getTickProgress(true);
            Projector.update(mc, td, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
            ModuleManager.hud(ctx, td);
        }

        // Watermark.
        int w = tr.getWidth("Mendingz Client") + 16;
        ctx.fill(4, 4, 4 + w, 20, 0xB00D0D11);
        ctx.fill(4, 4, 6, 20, ACCENT);
        ctx.drawText(tr, "Mendingz", 10, 8, 0xFFFFFFFF, true);
        ctx.drawText(tr, " Client", 10 + tr.getWidth("Mendingz"), 8, ACCENT, true);

        if (ModuleManager.SHOW_INFO.value && mc.player != null) drawInfo(ctx, mc, tr);

        if (!ModuleManager.SHOW_MODULE_LIST.value) return;

        // Enabled modules, longest name first.
        List<Module> on = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.enabled) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> tr.getWidth(label(m))).reversed());

        int sw = ctx.getScaledWindowWidth();
        int y = 4;
        for (Module m : on) {
            String text = label(m);
            int tw = tr.getWidth(text);
            ctx.fill(sw - tw - 12, y, sw, y + 12, 0xB00D0D11);
            ctx.fill(sw - 3, y, sw, y + 12, ACCENT);
            ctx.drawText(tr, text, sw - tw - 8, y + 2, 0xFFFFFFFF, true);
            y += 12;
        }
    }

    private static String label(Module m) {
        String i = m.info();
        return i == null ? m.name : m.name + " " + i;
    }

    private static void drawInfo(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        List<String> pills = new ArrayList<>();
        pills.add("FPS " + mc.getCurrentFps());
        pills.add("CPS " + Cps.get());
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        pills.add("Ping " + ping + "ms");
        pills.add("XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
        double cur = 0, max = 0;
        for (EquipmentSlot s : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = mc.player.getEquippedStack(s);
            if (!st.isEmpty() && st.getMaxDamage() > 0) {
                cur += st.getMaxDamage() - st.getDamage();
                max += st.getMaxDamage();
            }
        }
        pills.add("Armor " + (max == 0 ? 0 : (int) Math.round(cur / max * 100)) + "%");

        int h = ctx.getScaledWindowHeight();
        int y = h - 14 * pills.size() - 4;
        for (String p : pills) {
            int tw = tr.getWidth(p);
            ctx.fill(4, y, tw + 14, y + 12, 0xB00D0D11);
            ctx.fill(4, y, 6, y + 12, ACCENT);
            ctx.drawText(tr, p, 10, y + 2, 0xFFFFFFFF, true);
            y += 14;
        }
    }
}

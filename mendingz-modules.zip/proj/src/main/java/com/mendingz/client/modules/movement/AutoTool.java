package com.mendingz.client.modules.movement;

import com.mendingz.client.module.Module;
import com.mendingz.client.util.Inv;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Switches to the fastest hotbar tool while you mine, then switches back. */
public class AutoTool extends Module {
    private int prev = -1;

    public AutoTool() {
        super("AutoTool", Category.MOVEMENT, -1);
    }

    @Override
    protected void onDisable() {
        restore();
    }

    private void restore() {
        if (prev != -1 && mc.player != null) Inv.select(prev);
        prev = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!mc.options.attackKey.isPressed() || mc.currentScreen != null) {
            restore();
            return;
        }
        if (!(mc.crosshairTarget instanceof BlockHitResult b) || b.getType() != HitResult.Type.BLOCK) return;
        BlockState st = mc.world.getBlockState(b.getBlockPos());
        int best = Inv.selected();
        float bestSpeed = mc.player.getInventory().getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float sp = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best != Inv.selected()) {
            if (prev == -1) prev = Inv.selected();
            Inv.select(best);
        }
    }
}

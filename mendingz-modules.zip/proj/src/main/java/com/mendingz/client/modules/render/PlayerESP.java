package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Friends;
import com.mendingz.client.util.Projector;
import com.mendingz.client.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class PlayerESP extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 96, 16, 256, 8));
    private final Setting.Color color = add(new Setting.Color("Color", 0xE5173F));
    private final Setting.Color friendColor = add(new Setting.Color("Friend Color", 0x7CFF3B));
    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    private final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));

    public PlayerESP() {
        super("PlayerESP", Category.RENDER, GLFW.GLFW_KEY_E);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        for (PlayerEntity p : Targets.players(mc, range.value, true)) {
            Vec3d pos = p.getLerpedPos(td);
            Box b = p.getBoundingBox().offset(pos.x - p.getX(), pos.y - p.getY(), pos.z - p.getZ());
            int[] r = Projector.box(b);
            if (r == null) continue;
            int rgb = Friends.isFriend(p.getName().getString()) ? friendColor.rgb : color.rgb;
            Draw.box(ctx, r, rgb, fill.value ? 40 : 0);
            if (tracers.value) {
                Draw.line(ctx, Projector.width() / 2, Projector.height(), (r[0] + r[2]) / 2, r[3], 0xFF000000 | rgb);
            }
        }
    }
}

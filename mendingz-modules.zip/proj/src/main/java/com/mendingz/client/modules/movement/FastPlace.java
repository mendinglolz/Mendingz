package com.mendingz.client.modules.movement;

import com.mendingz.client.mixin.MinecraftClientAccessor;
import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;

public class FastPlace extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 4, 1));
    private final Setting.Bool blocksOnly = add(new Setting.Bool("Blocks Only", true));

    public FastPlace() {
        super("FastPlace", Category.MOVEMENT, -1);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (blocksOnly.value && !(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return;
        MinecraftClientAccessor a = (MinecraftClientAccessor) mc;
        if (a.mendingz$getItemUseCooldown() > (int) delay.value) a.mendingz$setItemUseCooldown((int) delay.value);
    }
}

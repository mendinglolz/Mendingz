package com.mendingz.client.util;

import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.modules.utility.FriendsModule;

import java.util.Set;
import java.util.TreeSet;

public final class Friends {
    public static final Set<String> NAMES = new TreeSet<>();

    private Friends() {}

    public static boolean isFriend(String name) {
        FriendsModule m = ModuleManager.get(FriendsModule.class);
        return m != null && m.enabled && NAMES.contains(name.toLowerCase());
    }
}

package com.mendingz.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int BG = 0xD00D0D11;

    private Draw() {}

    public static void line(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        for (int guard = 0; guard < 3000; guard++) {
            ctx.fill(x1, y1, x1 + 1, y1 + 1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx) { err += dx; y1 += sy; }
        }
    }

    /** Outlined rectangle with an optional translucent fill (fillAlpha 0-255). */
    public static void box(DrawContext ctx, int[] r, int rgb, int fillAlpha) {
        int c = 0xFF000000 | rgb;
        if (fillAlpha > 0) ctx.fill(r[0], r[1], r[2], r[3], (fillAlpha << 24) | (rgb & 0xFFFFFF));
        ctx.fill(r[0], r[1], r[2], r[1] + 1, c);
        ctx.fill(r[0], r[3] - 1, r[2], r[3], c);
        ctx.fill(r[0], r[1], r[0] + 1, r[3], c);
        ctx.fill(r[2] - 1, r[1], r[2], r[3], c);
    }

    /** Dark label with an accent border; centered on cx, bottom edge at bottomY. */
    public static void tag(DrawContext ctx, String[] lines, int cx, int bottomY, int rgb) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int tw = 0;
        for (String l : lines) tw = Math.max(tw, tr.getWidth(l));
        int w = tw + 8, h = lines.length * 10 + 4;
        int x = Math.max(2, Math.min(Projector.width() - w - 2, cx - w / 2));
        int y = Math.max(2, bottomY - h);
        ctx.fill(x, y, x + w, y + h, BG);
        int c = 0xFF000000 | rgb;
        ctx.fill(x, y, x + w, y + 1, c);
        ctx.fill(x, y + h - 1, x + w, y + h, c);
        ctx.fill(x, y, x + 1, y + h, c);
        ctx.fill(x + w - 1, y, x + w, y + h, c);
        for (int i = 0; i < lines.length; i++) {
            ctx.drawText(tr, lines[i], x + 4, y + 3 + i * 10, i == 0 ? c : 0xFFFFFFFF, false);
        }
    }

    public static String pretty(String id) {
        StringBuilder sb = new StringBuilder();
        for (String part : id.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}

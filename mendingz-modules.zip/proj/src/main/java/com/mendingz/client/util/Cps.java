package com.mendingz.client.util;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public final class Cps {
    private static final Deque<Long> CLICKS = new ArrayDeque<>();
    private static boolean down;

    private Cps() {}

    public static void tick(long window) {
        boolean d = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (d && !down) CLICKS.add(now);
        down = d;
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
    }

    public static int get() {
        return CLICKS.size();
    }
}

package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.EntityHitResult;

public class ReachDisplay extends Module {
    private double reach;
    private long seen;

    public ReachDisplay() {
        super("ReachDisplay", Category.COMBAT, -1);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            reach = mc.player.getEyePos().distanceTo(hit.getPos());
            seen = System.currentTimeMillis();
        }
    }

    @Override
    public void onHud(DrawContext ctx, float tickDelta) {
        if (System.currentTimeMillis() - seen > 2000) return;
        String t = String.format("Reach %.2f", reach);
        int x = ctx.getScaledWindowWidth() / 2 - mc.textRenderer.getWidth(t) / 2;
        ctx.drawText(mc.textRenderer, t, x, ctx.getScaledWindowHeight() / 2 + 14, 0xFFE5173F, true);
    }

    @Override
    public String info() {
        return System.currentTimeMillis() - seen > 2000 ? null : String.format("%.2f", reach);
    }
}

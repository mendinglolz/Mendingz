package com.mendingz.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

public final class Targets {
    private Targets() {}

    public static List<PlayerEntity> players(MinecraftClient mc, double range, boolean includeFriends) {
        List<PlayerEntity> out = new ArrayList<>();
        if (mc.world == null || mc.player == null) return out;
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (mc.player.distanceTo(p) > range) continue;
            if (!includeFriends && (Friends.isFriend(p.getName().getString()) || mc.player.isTeammate(p))) continue;
            out.add(p);
        }
        return out;
    }
}

package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.EntityHitResult;

/** Makes AutoClicker wait for a falling (critical) hit, and can jump for you. */
public class Criticals extends Module {
    private final Setting.Bool autoJump = add(new Setting.Bool("Auto Jump", true));
    private boolean jumped;

    public Criticals() {
        super("Criticals", Category.COMBAT, -1);
    }

    @Override
    protected void onDisable() {
        if (jumped) KeyBinding.updatePressedStates();
        jumped = false;
    }

    /** True when clicks should be held back because a crit is not possible right now. */
    public static boolean holdClicks(MinecraftClient mc) {
        Criticals c = ModuleManager.get(Criticals.class);
        if (c == null || !c.enabled) return false;
        ClientPlayerEntity p = mc.player;
        if (p.isTouchingWater() || p.isClimbing() || p.hasVehicle() || p.getAbilities().flying) return false;
        return !(!p.isOnGround() && p.getVelocity().y < 0 && p.fallDistance > 0);
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        if (jumped) {
            mc.options.jumpKey.setPressed(false);
            jumped = false;
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (autoJump.value && mc.currentScreen == null && mc.options.attackKey.isPressed()
            && mc.crosshairTarget instanceof EntityHitResult && mc.player.isOnGround()) {
            mc.options.jumpKey.setPressed(true);
            jumped = true;
        }
    }
}

package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.BlockScanner;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OreFinder extends Module {
    private static final String[] NAMES = {"Diamond", "Netherite", "Iron", "Coal", "Copper", "Emerald"};
    private static final int[] DEFAULT_COLORS = {0x3DF2E6, 0xC97B4A, 0xE8C9A8, 0xA0A0A8, 0xE07A3F, 0x2ECC40};

    private final Setting.Num range = add(new Setting.Num("Range", 64, 16, 128, 8));
    private final Setting.Num minY = add(new Setting.Num("Min Y", -64, -64, 320, 1));
    private final Setting.Num maxY = add(new Setting.Num("Max Y", 16, -64, 320, 1));
    private final Setting.Bool exposed = add(new Setting.Bool("Exposed Only", false));
    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    private final Setting.Bool tags = add(new Setting.Bool("Tags", true));
    private final Setting.Bool[] on = new Setting.Bool[NAMES.length];
    private final Setting.Color[] colors = new Setting.Color[NAMES.length];
    private final Map<Block, Integer> blockCat = new HashMap<>();
    private final BlockScanner scanner;
    private List<BlockScanner.Hit> hits = List.of();

    public OreFinder() {
        super("OreFinder", Category.RENDER, -1);
        for (int i = 0; i < NAMES.length; i++) {
            on[i] = add(new Setting.Bool(NAMES[i], true));
            colors[i] = add(new Setting.Color(NAMES[i] + " Color", DEFAULT_COLORS[i]));
        }
        for (Block b : Registries.BLOCK) {
            String p = Registries.BLOCK.getId(b).getPath();
            int c = p.endsWith("diamond_ore") ? 0 : p.equals("ancient_debris") ? 1 : p.endsWith("iron_ore") ? 2
                : p.endsWith("coal_ore") ? 3 : p.endsWith("copper_ore") ? 4 : p.endsWith("emerald_ore") ? 5 : -1;
            if (c >= 0) blockCat.put(b, c);
        }
        scanner = new BlockScanner(st -> blockCat.getOrDefault(st.getBlock(), -1));
    }

    @Override
    protected void onDisable() {
        scanner.clear();
        hits = List.of();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        scanner.tick(mc, (int) range.value, 2, 120);
        double lo = Math.min(minY.value, maxY.value), hi = Math.max(minY.value, maxY.value);
        List<BlockScanner.Hit> list = Finders.collect(scanner, range.value, c -> on[c].value);
        list.removeIf(h -> h.pos.getY() < lo || h.pos.getY() > hi || (exposed.value && !isExposed(mc, h.pos)));
        hits = list;
    }

    private static boolean isExposed(MinecraftClient mc, BlockPos p) {
        for (Direction d : Direction.values()) {
            if (!mc.world.getBlockState(p.offset(d)).isOpaque()) return true;
        }
        return false;
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        Finders.draw(ctx, hits, c -> colors[c].rgb, NAMES, fill.value, tags.value, 120, 6);
    }

    @Override
    public String info() {
        return String.valueOf(hits.size());
    }
}

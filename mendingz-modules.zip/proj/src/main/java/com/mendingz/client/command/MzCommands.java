package com.mendingz.client.command;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.ModuleManager;
import com.mendingz.client.util.Friends;
import com.mendingz.client.util.Waypoints;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * /mz toggle <module>
 * /mz friend add|remove <name> | list
 * /mz profile save|load <name> | list
 * /mz waypoint add|remove <name> | list
 */
public final class MzCommands {
    private MzCommands() {}

    private static void say(FabricClientCommandSource src, String msg) {
        src.sendFeedback(Text.literal("\u00a7c[Mendingz] \u00a7f" + msg));
    }

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
            ClientCommandManager.literal("mz")
                .then(ClientCommandManager.literal("toggle")
                    .then(ClientCommandManager.argument("module", StringArgumentType.word()).executes(c -> {
                        Module m = ModuleManager.byName(StringArgumentType.getString(c, "module"));
                        if (m == null) say(c.getSource(), "Unknown module.");
                        else m.toggle();
                        return 1;
                    })))
                .then(ClientCommandManager.literal("friend")
                    .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            Friends.NAMES.add(n.toLowerCase());
                            say(c.getSource(), "Added friend " + n);
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            say(c.getSource(), Friends.NAMES.remove(n.toLowerCase()) ? "Removed " + n : n + " is not a friend.");
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("list").executes(c -> {
                        say(c.getSource(), Friends.NAMES.isEmpty() ? "No friends." : String.join(", ", Friends.NAMES));
                        return 1;
                    })))
                .then(ClientCommandManager.literal("profile")
                    .then(ClientCommandManager.literal("save")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            say(c.getSource(), ConfigManager.save(n) ? "Saved profile " + n : "Could not save.");
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("load")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            say(c.getSource(), ConfigManager.load(n) ? "Loaded profile " + n : "Profile not found.");
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("list").executes(c -> {
                        say(c.getSource(), String.join(", ", ConfigManager.list()));
                        return 1;
                    })))
                .then(ClientCommandManager.literal("waypoint")
                    .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            MinecraftClient mc = MinecraftClient.getInstance();
                            if (mc.player == null) return 0;
                            Waypoints.Point p = new Waypoints.Point();
                            p.name = StringArgumentType.getString(c, "name");
                            p.x = mc.player.getBlockX();
                            p.y = mc.player.getBlockY();
                            p.z = mc.player.getBlockZ();
                            p.dim = mc.world.getRegistryKey().getValue().toString();
                            Waypoints.LIST.add(p);
                            Waypoints.save();
                            say(c.getSource(), "Waypoint " + p.name + " set at " + p.x + " " + p.y + " " + p.z);
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            say(c.getSource(), Waypoints.remove(n) ? "Removed " + n : "No such waypoint.");
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("list").executes(c -> {
                        for (Waypoints.Point p : Waypoints.LIST)
                            say(c.getSource(), p.name + ": " + p.x + " " + p.y + " " + p.z + " (" + p.dim + ")");
                        return 1;
                    })))
        ));
    }
}

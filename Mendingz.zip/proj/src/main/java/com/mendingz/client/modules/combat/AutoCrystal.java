package com.mendingz.client.modules.combat;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Inv;
import com.mendingz.client.util.Rand;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** When you place obsidian, places an end crystal on it and breaks it after a randomized delay. */
public class AutoCrystal extends Module {
    private final Setting.Num placeMin = add(new Setting.Num("Place Delay Min", 1, 0, 8, 1));
    private final Setting.Num placeMax = add(new Setting.Num("Place Delay Max", 3, 0, 8, 1));
    private final Setting.Num breakMin = add(new Setting.Num("Break Delay Min", 1, 0, 8, 1));
    private final Setting.Num breakMax = add(new Setting.Num("Break Delay Max", 3, 0, 8, 1));
    private final Setting.Num maxSelf = add(new Setting.Num("Max Self Damage", 6, 0, 20, 1));

    private enum State { IDLE, PLACE, BREAK }

    private State state = State.IDLE;
    private BlockPos pending, target;
    private int pendingAge, wait, prevSlot = -1;

    public AutoCrystal() {
        super("AutoCrystal", Category.COMBAT, GLFW.GLFW_KEY_H);
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private void reset() {
        state = State.IDLE;
        pending = null;
        target = null;
        if (prevSlot != -1 && mc.player != null) Inv.select(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;

        // Watch for an obsidian placement.
        if (state == State.IDLE) {
            if (mc.player.getMainHandStack().isOf(Items.OBSIDIAN) && mc.options.useKey.isPressed()
                && mc.crosshairTarget instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) {
                pending = b.getBlockPos().offset(b.getSide());
                pendingAge = 0;
            }
            if (pending != null) {
                if (mc.world.getBlockState(pending).isOf(Blocks.OBSIDIAN)) {
                    target = pending;
                    pending = null;
                    state = State.PLACE;
                    wait = Rand.range(placeMin.value, placeMax.value);
                } else if (++pendingAge > 10) {
                    pending = null;
                }
            }
            return;
        }

        if (wait-- > 0) return;

        if (state == State.PLACE) {
            if (!mc.world.getBlockState(target.up()).isAir() || !mc.world.getBlockState(target.up(2)).isAir()
                || selfDamage(mc, target) > maxSelf.value) {
                reset();
                return;
            }
            int slot = Inv.findHotbar(s -> s.isOf(Items.END_CRYSTAL));
            if (slot == -1) {
                reset();
                return;
            }
            prevSlot = Inv.selected();
            Inv.select(slot);
            Vec3d hitPos = Vec3d.ofCenter(target).add(0, 0.5, 0);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitPos, Direction.UP, target, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            state = State.BREAK;
            wait = Rand.range(breakMin.value, breakMax.value);
        } else if (state == State.BREAK) {
            List<EndCrystalEntity> crystals = mc.world.getEntitiesByClass(EndCrystalEntity.class, new Box(target.up()), e -> true);
            if (!crystals.isEmpty() && mc.player.distanceTo(crystals.get(0)) < 4.5) {
                mc.interactionManager.attackEntity(mc.player, crystals.get(0));
                mc.player.swingHand(Hand.MAIN_HAND);
            }
            reset();
        }
    }

    /** Rough estimate of damage you would take from a crystal on top of this block. */
    private static double selfDamage(MinecraftClient mc, BlockPos obsidian) {
        Vec3d c = new Vec3d(obsidian.getX() + 0.5, obsidian.getY() + 1.0, obsidian.getZ() + 0.5);
        double d = mc.player.getEntityPos().distanceTo(c) / 12.0;
        if (d > 1.0) return 0;
        double impact = 1.0 - d;
        double dmg = (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;
        return dmg * (1.0 - Math.min(20, mc.player.getArmor()) / 25.0);
    }
}

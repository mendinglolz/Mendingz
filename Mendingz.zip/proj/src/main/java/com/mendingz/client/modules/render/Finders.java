package com.mendingz.client.modules.render;

import com.mendingz.client.util.BlockScanner;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntPredicate;
import java.util.function.IntUnaryOperator;

/** Shared drawing for BaseFinder, OreFinder and StorageESP. */
final class Finders {
    private Finders() {}

    static List<BlockScanner.Hit> collect(BlockScanner scanner, double range, IntPredicate enabled) {
        Vec3d me = MinecraftClient.getInstance().player.getEntityPos();
        List<BlockScanner.Hit> out = new ArrayList<>();
        scanner.forEach(h -> {
            if (enabled.test(h.cat) && h.pos.toCenterPos().distanceTo(me) <= range) out.add(h);
        });
        out.sort((a, b) -> Double.compare(a.pos.getSquaredDistance(me), b.pos.getSquaredDistance(me)));
        return out;
    }

    /** Draws up to maxBoxes boxes and maxTags labels. */
    static void draw(DrawContext ctx, List<BlockScanner.Hit> hits, IntUnaryOperator color, String[] names,
                     boolean fill, boolean tags, int maxBoxes, int maxTags) {
        Vec3d me = MinecraftClient.getInstance().player.getEntityPos();
        int tagged = 0;
        for (int i = 0; i < Math.min(maxBoxes, hits.size()); i++) {
            BlockScanner.Hit h = hits.get(i);
            int[] r = Projector.box(new Box(h.pos));
            if (r == null) continue;
            int rgb = color.applyAsInt(h.cat);
            Draw.box(ctx, r, rgb, fill ? 45 : 0);
            if (tags && tagged < maxTags) {
                tagged++;
                BlockPos p = h.pos;
                int d = (int) Math.sqrt(p.getSquaredDistance(me));
                Draw.tag(ctx, new String[] {names[h.cat] + "  " + d + "m", p.getX() + " " + p.getY() + " " + p.getZ()},
                    (r[0] + r[2]) / 2, r[1] - 3, rgb);
            }
        }
    }
}

package com.mendingz.client.modules.utility;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.BlockScanner;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Highlights spawners, trial spawners and vaults through walls. */
public class SpawnerFinder extends Module {
    private static final String[] NAMES = {"Spawner", "Trial Spawner", "Vault"};
    private final Setting.Num range = add(new Setting.Num("Range", 96, 32, 192, 16));
    private final Setting.Color spawner = add(new Setting.Color("Spawner Color", 0xE5173F));
    private final Setting.Color trial = add(new Setting.Color("Trial Color", 0x2BC4FF));
    private final Setting.Color vault = add(new Setting.Color("Vault Color", 0xFFD02B));
    private final BlockScanner scanner = new BlockScanner(st ->
        st.isOf(Blocks.SPAWNER) ? 0 : st.isOf(Blocks.TRIAL_SPAWNER) ? 1 : st.isOf(Blocks.VAULT) ? 2 : -1);

    public SpawnerFinder() {
        super("SpawnerFinder", Category.UTILITY, -1);
    }

    @Override
    protected void onDisable() {
        scanner.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        scanner.tick(mc, (int) range.value, 2, 100);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        Vec3d me = mc.player.getEntityPos();
        List<BlockScanner.Hit> hits = new ArrayList<>();
        scanner.forEach(h -> {
            if (h.pos.toCenterPos().distanceTo(me) <= range.value) hits.add(h);
        });
        hits.sort((a, b) -> Double.compare(a.pos.getSquaredDistance(me), b.pos.getSquaredDistance(me)));
        int tags = 0;
        for (int i = 0; i < Math.min(60, hits.size()); i++) {
            BlockScanner.Hit h = hits.get(i);
            int rgb = h.cat == 0 ? spawner.rgb : h.cat == 1 ? trial.rgb : vault.rgb;
            int[] r = Projector.box(new Box(h.pos));
            if (r == null) continue;
            Draw.box(ctx, r, rgb, 60);
            if (tags++ < 5) {
                int d = (int) Math.sqrt(h.pos.getSquaredDistance(me));
                Draw.tag(ctx, new String[] {NAMES[h.cat] + " " + d + "m", h.pos.getX() + " " + h.pos.getY() + " " + h.pos.getZ()},
                    (r[0] + r[2]) / 2, r[1] - 3, rgb);
            }
        }
    }

    @Override
    public String info() {
        int[] n = {0};
        scanner.forEach(h -> n[0]++);
        return String.valueOf(n[0]);
    }
}

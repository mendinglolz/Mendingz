package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;

public class Trail extends Module {
    private final Setting.Num length = add(new Setting.Num("Length (ticks)", 120, 20, 600, 10));
    private final Setting.Color color = add(new Setting.Color("Color", 0xE5173F));
    private final Deque<Vec3d> points = new ArrayDeque<>();

    public Trail() {
        super("Trail", Category.RENDER, -1);
    }

    @Override
    protected void onDisable() {
        points.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        points.addLast(mc.player.getEntityPos().add(0, 0.1, 0));
        while (points.size() > length.value) points.pollFirst();
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        double[] prev = null;
        int i = 0, n = points.size();
        for (Vec3d p : points) {
            double[] s = Projector.project(p.x, p.y, p.z);
            if (s != null && prev != null) {
                int alpha = 40 + (int) (215.0 * i / Math.max(1, n));
                Draw.line(ctx, (int) prev[0], (int) prev[1], (int) s[0], (int) s[1], (alpha << 24) | color.rgb);
            }
            prev = s;
            i++;
        }
    }
}

package com.mendingz.client.modules.utility;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

public class AutoReconnect extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (sec)", 5, 1, 60, 1));
    private ServerInfo last;
    private long at = -1;

    public AutoReconnect() {
        super("AutoReconnect", Category.UTILITY, -1);
    }

    @Override
    protected void onDisable() {
        at = -1;
    }

    @Override
    public void onAlwaysTick(MinecraftClient mc) {
        if (mc.world != null) {
            ServerInfo s = mc.getCurrentServerEntry();
            if (s != null) last = s;
            at = -1;
            return;
        }
        if (last == null || !(mc.currentScreen instanceof DisconnectedScreen)) {
            at = -1;
            return;
        }
        long now = System.currentTimeMillis();
        if (at < 0) at = now + (long) (delay.value * 1000);
        if (now >= at) {
            at = -1;
            ConnectScreen.connect(new TitleScreen(), mc, ServerAddress.parse(last.address), last, false, null);
        }
    }
}

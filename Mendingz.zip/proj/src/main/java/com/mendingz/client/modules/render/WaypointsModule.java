package com.mendingz.client.modules.render;

import com.mendingz.client.module.Module;
import com.mendingz.client.module.Setting;
import com.mendingz.client.util.Draw;
import com.mendingz.client.util.Projector;
import com.mendingz.client.util.Waypoints;
import net.minecraft.client.gui.DrawContext;

/** Shows named waypoints. Add them with /mz waypoint add <name>. */
public class WaypointsModule extends Module {
    private final Setting.Color color = add(new Setting.Color("Color", 0x2BC4FF));
    private final Setting.Num maxDist = add(new Setting.Num("Max Distance", 2000, 100, 10000, 100));

    public WaypointsModule() {
        super("Waypoints", Category.RENDER, -1);
    }

    @Override
    public void onHud(DrawContext ctx, float td) {
        String dim = mc.world.getRegistryKey().getValue().toString();
        for (Waypoints.Point p : Waypoints.LIST) {
            if (!dim.equals(p.dim)) continue;
            double d = mc.player.getEntityPos().distanceTo(new net.minecraft.util.math.Vec3d(p.x + 0.5, p.y + 0.5, p.z + 0.5));
            if (d > maxDist.value) continue;
            double[] s = Projector.project(p.x + 0.5, p.y + 1.0, p.z + 0.5);
            if (s == null) continue;
            int x = (int) s[0], y = (int) s[1];
            ctx.fill(x - 2, y, x + 3, y + 5, 0xFF000000 | color.rgb);
            Draw.tag(ctx, new String[] {p.name, (int) d + "m"}, x, y - 3, color.rgb);
        }
    }

    @Override
    public String info() {
        return String.valueOf(Waypoints.LIST.size());
    }
}
